# LabControll 4.0 — Projeto LaTeX

## Estrutura do projeto

```
labcontroll_latex/
├── main.tex                          ← arquivo principal (compilar este)
├── macros.tex                        ← macros do autor
├── referencias.bib                   ← referências BibTeX (ABNT)
└── conteudo/
    ├── pretextuais/
    │   └── 6-resumo_abstract.tex     ← Resumo (PT) e Abstract (EN)
    └── capitulos/
        ├── 1-introducao.tex
        ├── 2-revisao.tex
        ├── 3-metodologia.tex
        ├── 4-resultados.tex
        ├── 5-conclusao.tex
        └── 6-agradecimentos.tex
```

## Como compilar (ordem obrigatória)

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

> A tripla compilação é necessária para resolver referências cruzadas e a bibliografia ABNT.

## Requisitos

- **Classe**: `abntex2` (instalar via TeX Live: `sudo tlmgr install abntex2`)
- **Distribuição recomendada**: TeX Live 2022+ ou MiKTeX 22+
- **Compilador**: `pdflatex` (ou `xelatex` se preferir)

## Editores online

O projeto pode ser compilado diretamente no **Overleaf**:
1. Crie um novo projeto em branco
2. Faça upload de todos os arquivos mantendo a estrutura de pastas
3. Compile com `pdflatex`

## Notas

- O sumário é gerado automaticamente pelo comando `\tableofcontents*`
- As citações seguem o padrão **ABNT NBR 6023** via pacote `abntex2cite`
- Para adicionar figuras, coloque os arquivos na pasta raiz ou em `conteudo/figuras/`
  e use: `\includegraphics[width=0.8\textwidth]{nome-da-figura}`
